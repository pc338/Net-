package com.nettrack.app

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Good = Color(0xFF2ECC71)
val Average = Color(0xFFF1C40F)
val Poor = Color(0xFFE74C3C)

data class Operator(val name: String, val color: Color)
val Operators = listOf(
    Operator("Jio", Color(0xFF1E5BFF)),
    Operator("Airtel", Color(0xFFE53935)),
    Operator("Vi", Color(0xFFFF9800)),
    Operator("BSNL", Color(0xFF00A86B)),
)

@Composable
fun NetTrackTheme(dark: Boolean, content: @Composable () -> Unit) {
    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF26C6DA), background = Color(0xFF0E1621), surface = Color(0xFF16202D),
        surfaceVariant = Color(0xFF1F2B3B)
    ) else lightColorScheme(
        primary = Color(0xFF00897B), background = Color(0xFFF4F7FA), surface = Color.White,
        surfaceVariant = Color(0xFFE6ECF2)
    )
    MaterialTheme(colorScheme = colors, content = content)
}
