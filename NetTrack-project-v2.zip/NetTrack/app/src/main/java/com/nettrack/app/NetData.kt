package com.nettrack.app

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import android.location.Location
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class TestResult(
    val time: Long, val operator: String, val connection: String,
    val download: Double, val upload: Double, val pingMs: Double, val jitterMs: Double,
    val lat: Double? = null, val lon: Double? = null
)

data class NetInfo(val operator: String, val connection: String)

fun normalizeOperator(raw: String): String {
    val s = raw.lowercase().trim()
    return when {
        s.isBlank() -> "Unknown"
        "jio" in s -> "Jio"
        "airtel" in s -> "Airtel"
        "vodafone" in s || "idea" in s || s == "vi" || s.startsWith("vi ") || s.startsWith("vi-") -> "Vi"
        "bsnl" in s || "cellone" in s -> "BSNL"
        else -> raw.trim()
    }
}

fun readNetInfo(ctx: Context): NetInfo {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val tm = ctx.getSystemService(TelephonyManager::class.java)
    return when {
        caps == null -> NetInfo("--", "Offline")
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetInfo("Wi-Fi", "Wi-Fi")
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
            NetInfo(normalizeOperator(tm.networkOperatorName ?: ""), cellType(ctx, tm))
        else -> NetInfo("Other", "Other")
    }
}

private fun cellType(ctx: Context, tm: TelephonyManager): String = try {
    val ok = android.os.Build.VERSION.SDK_INT < 30 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    if (!ok) "Mobile data" else when (tm.dataNetworkType) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G"
        TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
        TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS -> "2G"
        else -> "Mobile data"
    }
} catch (e: SecurityException) { "Mobile data" }

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("nettrack", Context.MODE_PRIVATE)

    fun load(c: Context): List<TestResult> {
        val a = JSONArray(prefs(c).getString("history", "[]"))
        return List(a.length()) { i ->
            a.getJSONObject(i).let {
                TestResult(it.getLong("t"), it.getString("op"), it.getString("conn"),
                    it.getDouble("d"), it.getDouble("u"), it.getDouble("p"), it.getDouble("j"),
                    if (it.has("lat")) it.getDouble("lat") else null,
                    if (it.has("lon")) it.getDouble("lon") else null)
            }
        }
    }

    private fun save(c: Context, l: List<TestResult>) {
        val a = JSONArray()
        l.forEach { r ->
            val o = JSONObject().put("t", r.time).put("op", r.operator).put("conn", r.connection)
                .put("d", r.download).put("u", r.upload).put("p", r.pingMs).put("j", r.jitterMs)
            if (r.lat != null && r.lon != null) { o.put("lat", r.lat); o.put("lon", r.lon) }
            a.put(o)
        }
        prefs(c).edit().putString("history", a.toString()).apply()
    }

    fun add(c: Context, r: TestResult): List<TestResult> {
        val l = (listOf(r) + load(c)).take(1000); save(c, l); return l
    }

    fun clear(c: Context) { save(c, emptyList()) }

    fun saveLocationPref(c: Context): Boolean = prefs(c).getBoolean("save_loc", true)
    fun sharePref(c: Context): Boolean = prefs(c).getBoolean("share", false)
    fun setSharePref(c: Context, v: Boolean) { prefs(c).edit().putBoolean("share", v).apply() }
    fun setSaveLocationPref(c: Context, v: Boolean) { prefs(c).edit().putBoolean("save_loc", v).apply() }
}

class NetViewModel(app: Application) : AndroidViewModel(app) {
    var running by mutableStateOf(false)
    var phase by mutableStateOf("")
    var liveSpeed by mutableStateOf<Float?>(null)
    var ping by mutableStateOf<Double?>(null)
    var jitter by mutableStateOf<Double?>(null)
    var download by mutableStateOf<Double?>(null)
    var upload by mutableStateOf<Double?>(null)
    var error by mutableStateOf<String?>(null)
    var history by mutableStateOf(Store.load(app))
    var net by mutableStateOf(readNetInfo(app))
    var saveLocation by mutableStateOf(Store.saveLocationPref(app))

    var shareData by mutableStateOf(Store.sharePref(app))
    var scanning by mutableStateOf(false)
    var scanCount by mutableStateOf(0)
    var scanMsg by mutableStateOf("")
    var target by mutableStateOf<MapPoint?>(null)
    var verifyMsg by mutableStateOf("")
    private var scanJob: Job? = null

    fun toggleScan() { if (scanning) stopScan() else startScan() }

    fun stopScan() { scanJob?.cancel(); scanJob = null; scanning = false; scanMsg = "" }

    /** Takes a light speed+ping sample every ~100 m moved, while the app is open. */
    fun startScan() {
        if (scanning) return
        scanning = true; scanCount = 0; scanMsg = "Starting…"
        scanJob = viewModelScope.launch {
            var lastLoc: Location? = null
            while (true) {
                if (running) { delay(3000); continue }
                refreshNet()
                if (net.connection == "Offline") { scanMsg = "Offline, waiting…"; delay(5000); continue }
                val loc = getLocation(getApplication())
                if (loc == null) { scanMsg = "Waiting for GPS…"; delay(5000); continue }
                val moved = lastLoc?.distanceTo(loc) ?: Float.MAX_VALUE
                if (moved >= 100f) {
                    scanMsg = "Measuring…"
                    try {
                        val (p, d) = SpeedEngine.quick()
                        val r = TestResult(System.currentTimeMillis(), net.operator, net.connection,
                            d, 0.0, p, 0.0, loc.latitude, loc.longitude)
                        history = Store.add(getApplication(), r)
                        scanCount++
                        lastLoc = loc
                        scanMsg = "Sample saved"
                        if (shareData && Config.enabled) {
                            viewModelScope.launch {
                                try { Cloud.upload(r, loc.latitude, loc.longitude) } catch (e: Exception) { }
                            }
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        scanMsg = "Sample failed: ${e.message ?: "network error"}"
                    }
                } else scanMsg = "Move about 100 m for the next sample"
                delay(5000)
            }
        }
    }

    var community by mutableStateOf<List<CommunityPoint>>(emptyList())
    var communityMsg by mutableStateOf("")
    var communityLoading by mutableStateOf(false)
    var myLat by mutableStateOf<Double?>(null)
    var myLon by mutableStateOf<Double?>(null)

    /** Loads community tests around a tapped map point and merges them with what is already loaded. */
    fun loadCommunityAt(lat: Double, lon: Double) {
        if (!Config.enabled) return
        viewModelScope.launch {
            communityLoading = true
            try {
                val more = Cloud.fetchNear(lat, lon)
                community = (community + more).distinctBy { Triple(it.lat, it.lon, it.time) }
                communityMsg = ""
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                communityMsg = "Could not load: ${e.message ?: "network error"}"
            } finally { communityLoading = false }
        }
    }

    fun setShare(v: Boolean) { shareData = v; Store.setSharePref(getApplication(), v) }

    fun loadCommunity() {
        if (!Config.enabled) { communityMsg = "Community map is not set up yet."; return }
        viewModelScope.launch {
            communityLoading = true; communityMsg = ""
            try {
                val loc = getLocation(getApplication())
                if (loc == null) { communityMsg = "Allow location (and turn it on) to load nearby community tests."; return@launch }
                myLat = loc.latitude; myLon = loc.longitude
                community = Cloud.fetchNear(loc.latitude, loc.longitude)
                if (community.isEmpty()) communityMsg = "No community tests near you yet."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                communityMsg = "Could not load: ${e.message ?: "network error"}"
            } finally { communityLoading = false }
        }
    }

    fun setSaveLoc(v: Boolean) { saveLocation = v; Store.setSaveLocationPref(getApplication(), v) }

    fun refreshNet() { net = readNetInfo(getApplication()) }

    fun clearHistory() { Store.clear(getApplication()); history = emptyList() }

    fun start(verify: MapPoint? = null) {
        if (running) return
        viewModelScope.launch {
            running = true; error = null
            if (verify != null) verifyMsg = ""
            ping = null; jitter = null; download = null; upload = null; liveSpeed = null
            refreshNet()
            if (net.connection == "Offline") { error = "No internet connection"; running = false; return@launch }
            val locJob = if (saveLocation || shareData) async { getLocation(getApplication()) } else null
            try {
                phase = "Measuring ping…"
                val (p, j) = SpeedEngine.ping(); ping = p; jitter = j
                phase = "Testing download…"
                download = SpeedEngine.download { liveSpeed = it.toFloat() }
                liveSpeed = download?.toFloat()
                phase = "Testing upload…"
                upload = SpeedEngine.upload { liveSpeed = it.toFloat() }
                liveSpeed = upload?.toFloat()
                val loc = locJob?.await()
                val r = TestResult(System.currentTimeMillis(), net.operator, net.connection,
                    download!!, upload!!, p, j,
                    if (saveLocation) loc?.latitude else null, if (saveLocation) loc?.longitude else null)
                history = Store.add(getApplication(), r)
                if (shareData && Config.enabled && loc != null) {
                    viewModelScope.launch {
                        try { Cloud.upload(r, loc.latitude, loc.longitude) } catch (e: Exception) { /* sharing is best-effort */ }
                    }
                }
                phase = "Done"
                if (verify != null) verifyMsg =
                    "Recorded: ${f1(verify.download)} Mbps, ping ${f1(verify.ping)} ms  →  Now: ${f1(download)} Mbps, ping ${f1(p)} ms"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Test failed: ${e.message ?: "network error"}"; phase = ""
            } finally { running = false }
        }
    }
}
