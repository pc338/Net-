package com.nettrack.app

import kotlinx.coroutines.*
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min

/**
 * Real measurements against Cloudflare's public speed-test endpoints (HTTPS).
 * Speed = bytes moved after a warm-up (TCP slow start is excluded) over several parallel connections.
 * Upload only counts bytes the server has confirmed receiving.
 */
object SpeedEngine {
    private const val DOWN = "https://speed.cloudflare.com/__down?bytes="
    private const val UP = "https://speed.cloudflare.com/__up"
    private const val TEST_NANOS = 10_000_000_000L
    private const val WARM_NANOS = 2_500_000_000L

    private class Meter(val testNanos: Long, val warmNanos: Long, val cap: Long = Long.MAX_VALUE) {
        val total = AtomicLong(0)
        val errors = AtomicInteger(0)
        val start = System.nanoTime()
        val deadline = start + testNanos
        @Volatile var warmBytes = -1L
        @Volatile var warmTime = 0L
        fun more() = System.nanoTime() < deadline && total.get() < cap

        suspend fun report(onSpeed: (Double) -> Unit) {
            var lastB = 0L; var lastT = start
            while (true) {
                delay(300)
                val now = System.nanoTime(); val b = total.get()
                onSpeed((b - lastB) * 8.0 / ((now - lastT) / 1e9) / 1e6)
                if (warmBytes < 0 && now - start >= warmNanos) { warmBytes = b; warmTime = now }
                lastB = b; lastT = now
            }
        }

        fun result(): Double {
            val now = System.nanoTime(); val b = total.get()
            if (b == 0L) throw IllegalStateException("no data received")
            return if (warmBytes >= 0 && now > warmTime && b > warmBytes)
                (b - warmBytes) * 8.0 / ((now - warmTime) / 1e9) / 1e6
            else b * 8.0 / ((now - start) / 1e9) / 1e6
        }
    }

    /** Returns (median HTTP round-trip ms, jitter ms). The first sample (connection setup) is discarded. */
    suspend fun ping(samples: Int = 11): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val t = mutableListOf<Double>()
        repeat(samples) {
            val t0 = System.nanoTime()
            val c = URL(DOWN + "0").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.inputStream.use { it.readBytes() }
            t += (System.nanoTime() - t0) / 1e6
        }
        val s = t.drop(1)
        val sorted = s.sorted()
        sorted[sorted.size / 2] to s.zipWithNext { a, b -> abs(a - b) }.average()
    }

    private suspend fun downloadCore(
        onSpeed: (Double) -> Unit, testNanos: Long, warmNanos: Long, conns: Int, cap: Long, chunk: Int
    ): Double = coroutineScope {
        val m = Meter(testNanos, warmNanos, cap)
        val workers = List(conns) {
            async(Dispatchers.IO) {
                val buf = ByteArray(64 * 1024)
                while (m.more() && isActive) {
                    val c = URL(DOWN + chunk).openConnection() as HttpURLConnection
                    try {
                        c.connectTimeout = 8000; c.readTimeout = 8000
                        c.inputStream.use { s ->
                            while (m.more()) {
                                val n = s.read(buf); if (n < 0) break
                                m.total.addAndGet(n.toLong())
                            }
                        }
                    } catch (e: IOException) {
                        if (m.errors.incrementAndGet() >= 8 && m.total.get() == 0L) throw e
                        delay(200)
                    } finally { c.disconnect() }
                }
            }
        }
        val reporter = launch { m.report(onSpeed) }
        workers.awaitAll(); reporter.cancel()
        m.result()
    }

    suspend fun download(onSpeed: (Double) -> Unit): Double =
        downloadCore(onSpeed, TEST_NANOS, WARM_NANOS, 6, Long.MAX_VALUE, 50_000_000)

    /** Light sample for auto-scan: (ping ms, download Mbps). Uses at most ~6 MB of data. */
    suspend fun quick(): Pair<Double, Double> {
        val p = ping(5).first
        val d = downloadCore({}, 5_000_000_000L, 1_000_000_000L, 4, 6_000_000L, 10_000_000)
        return p to d
    }

    suspend fun upload(onSpeed: (Double) -> Unit): Double = coroutineScope {
        val m = Meter(TEST_NANOS, WARM_NANOS)
        val workers = List(4) {
            async(Dispatchers.IO) {
                val chunk = ByteArray(32 * 1024)
                var size = 128_000 // grows while requests finish quickly
                while (m.more() && isActive) {
                    val c = URL(UP).openConnection() as HttpURLConnection
                    val t0 = System.nanoTime()
                    try {
                        c.requestMethod = "POST"; c.doOutput = true
                        c.connectTimeout = 8000; c.readTimeout = 20000
                        c.setFixedLengthStreamingMode(size)
                        c.outputStream.use { o ->
                            var sent = 0
                            while (sent < size) {
                                val n = min(chunk.size, size - sent)
                                o.write(chunk, 0, n); sent += n
                            }
                        }
                        c.inputStream.use { it.readBytes() } // wait for the server's confirmation
                        m.total.addAndGet(size.toLong())     // count only confirmed bytes
                        if ((System.nanoTime() - t0) < 1_500_000_000L && size < 2_000_000) size *= 2
                    } catch (e: IOException) {
                        c.disconnect()
                        if (m.errors.incrementAndGet() >= 8 && m.total.get() == 0L) throw e
                        delay(200)
                    }
                }
            }
        }
        val reporter = launch { m.report(onSpeed) }
        workers.awaitAll(); reporter.cancel()
        m.result()
    }
}
