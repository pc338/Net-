package com.nettrack.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.io.File
import android.graphics.drawable.GradientDrawable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import androidx.compose.foundation.horizontalScroll
import kotlinx.coroutines.delay

/** Speedometer. value == null means "no measurement" and shows "--" (never a fake number). */
@Composable
fun Speedometer(value: Float?, max: Float = 100f, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val prim = MaterialTheme.colorScheme.primary
    val sweep = 240f * ((value ?: 0f) / max).coerceIn(0f, 1f)
    Box(modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val inset = 24f
            val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
            val st = Stroke(width = 24f, cap = StrokeCap.Round)
            drawArc(track, 150f, 240f, false, Offset(inset, inset), sz, style = st)
            if (sweep > 0f) drawArc(prim, 150f, sweep, false, Offset(inset, inset), sz, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.1f".format(it) } ?: "--", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text("Mbps", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun SourceChip(label: String, color: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

fun meterMax(v: Float?) = when { v == null || v <= 100f -> 100f; v <= 300f -> 300f; else -> 1000f }
fun fmtTime(t: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))
fun f1(v: Double?) = v?.let { "%.1f".format(it) } ?: "--"
fun distText(d: Float) = if (d < 1000) "${d.toInt()} m" else "%.1f km".format(d / 1000)
fun fu(v: Double) = if (v <= 0.0) "--" else f1(v) // upload 0 = not measured (auto-scan sample)

fun openMaps(ctx: android.content.Context, lat: Double, lon: Double) {
    try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
            android.net.Uri.parse("geo:0,0?q=$lat,$lon(Fastest+spot)")))
    } catch (e: Exception) { }
}

@Composable
fun HomeScreen(vm: NetViewModel, onRunTest: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshNet() }
    LaunchedEffect(Unit) {
        vm.refreshNet()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.READ_PHONE_STATE)
    }
    val last = vm.history.firstOrNull { it.upload > 0.0 }
    Page {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Current network (read from device)", fontSize = 12.sp)
                Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Speedometer(last?.download?.toFloat(), meterMax(last?.download?.toFloat()))
                if (last != null) SourceChip("Historical: last test ${fmtTime(last.time)}", Color(0xFF1E5BFF))
                else SourceChip("No test run yet", Color.Gray)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", "${f1(last?.download)} Mbps", Modifier.weight(1f))
            StatCard("Upload", "${f1(last?.upload)} Mbps", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping", "${f1(last?.pingMs)} ms", Modifier.weight(1f))
            StatCard("Jitter", "${f1(last?.jitterMs)} ms", Modifier.weight(1f))
        }
        Button(onClick = onRunTest, Modifier.fillMaxWidth()) { Text("Run speed test") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SourceChip("Live", Good); SourceChip("Historical", Color(0xFF1E5BFF)); SourceChip("Reported", Average)
        }
        SourceChip("Estimated coverage (never shown as live speed)", Color.Gray)
    }
}

data class MapPoint(
    val operator: String, val connection: String, val download: Double, val upload: Double,
    val ping: Double, val lat: Double, val lon: Double, val time: Long
)

private class Holder(
    var key: String? = null,
    var overlay: MyLocationNewOverlay? = null,
    var map: MapView? = null,
    var liveCentered: Boolean = false
)

fun qualityColor(download: Double) = when { download >= 20.0 -> Good; download >= 5.0 -> Average; else -> Poor }
fun pingColor(ms: Double) = when { ms < 50.0 -> Good; ms < 100.0 -> Average; else -> Poor }

@Composable
fun MapScreen(vm: NetViewModel) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf<String?>(null) }
    var community by remember { mutableStateOf(false) }
    var byPing by remember { mutableStateOf(false) }
    var radius by remember { mutableStateOf<Int?>(null) }
    var permTick by remember { mutableStateOf(0) }
    var live by remember { mutableStateOf<GeoPoint?>(null) }
    var tapPoint by remember { mutableStateOf<GeoPoint?>(null) }
    var fasterOnly by remember { mutableStateOf(false) }
    var tapRadius by remember { mutableStateOf(2000) } // meters, 0 = no limit
    val holder = remember { Holder() }
    val centered = remember { Holder() }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permTick++
        if (community) vm.loadCommunity()
    }
    fun askPermission() = permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    fun openCommunity() {
        community = true
        if (!hasLocationPermission(ctx)) askPermission() else vm.loadCommunity()
    }
    LaunchedEffect(Unit) { if (!hasLocationPermission(ctx)) askPermission() }
    LaunchedEffect(permTick) {
        while (true) {
            val g = holder.overlay?.myLocation
            if (g != null) {
                live = g
                if (!holder.liveCentered) {
                    holder.map?.controller?.setZoom(17.0)
                    holder.map?.controller?.animateTo(g)
                    holder.liveCentered = true
                }
            }
            delay(1500)
        }
    }
    DisposableEffect(Unit) {
        onDispose { holder.overlay?.disableMyLocation(); holder.map?.onDetach() }
    }

    val all: List<MapPoint> = if (community)
        vm.community.map { MapPoint(it.operator, it.connection, it.download, it.upload, it.ping, it.lat, it.lon, it.time) }
    else vm.history.filter { it.lat != null && it.lon != null }
        .map { MapPoint(it.operator, it.connection, it.download, it.upload, it.pingMs, it.lat!!, it.lon!!, it.time) }

    val userLa = live?.latitude ?: vm.myLat
    val userLo = live?.longitude ?: vm.myLon
    fun distTo(p: MapPoint): Float? {
        if (userLa == null || userLo == null) return null
        val res = FloatArray(1)
        android.location.Location.distanceBetween(userLa, userLo, p.lat, p.lon, res)
        return res[0]
    }
    val mine = vm.history.firstOrNull()
    fun fasterThanMine(p: MapPoint) = mine == null || (if (byPing) p.ping < mine.pingMs else p.download > mine.download)
    val rad = radius
    val points = all.filter { p ->
        (selected == null || p.operator == selected) &&
            (!fasterOnly || fasterThanMine(p)) &&
            (rad == null || (distTo(p)?.let { it <= rad } ?: true))
    }

    val summary = Operators.mapNotNull { op ->
        val l = points.filter { it.operator == op.name }
        if (l.isEmpty()) null
        else if (byPing) "${op.name} ${f1(l.map { it.ping }.average())} ms (${l.size})"
        else "${op.name} ${f1(l.map { it.download }.average())} Mbps (${l.size})"
    }
    val best = if (byPing) points.minByOrNull { it.ping } else points.maxByOrNull { it.download }
    val bestDist = best?.let { distTo(it) }
    val tgt = vm.target
    val tgtDist = tgt?.let { distTo(it) }
    val tp = tapPoint
    val refLa = tp?.latitude ?: userLa
    val refLo = tp?.longitude ?: userLo
    val showList = tp != null || fasterOnly
    val rr = tapRadius
    val spots: List<Pair<MapPoint, Float>> = if (!showList || refLa == null || refLo == null) emptyList() else all
        .filter { (selected == null || it.operator == selected) && (!fasterOnly || fasterThanMine(it)) }
        .map { p ->
            val res = FloatArray(1)
            android.location.Location.distanceBetween(refLa, refLo, p.lat, p.lon, res)
            p to res[0]
        }
        .filter { rr == 0 || it.second <= rr }
        .let { l -> if (byPing) l.sortedBy { it.first.ping } else l.sortedByDescending { it.first.download } }
        .take(50)

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = !community, onClick = { community = false }, label = { Text("My tests") })
            FilterChip(selected = community, onClick = { openCommunity() }, label = { Text("Community") })
            FilterChip(selected = !byPing, onClick = { byPing = false }, label = { Text("Speed") })
            FilterChip(selected = byPing, onClick = { byPing = true }, label = { Text("Ping") })
            FilterChip(selected = fasterOnly, onClick = { fasterOnly = !fasterOnly }, label = { Text("Faster than mine") })
            FilterChip(selected = vm.scanning, onClick = {
                if (!vm.scanning && !hasLocationPermission(ctx)) askPermission() else vm.toggleScan()
            }, label = { Text(if (vm.scanning) "Auto-scan ON" else "Auto-scan") })
            if (community) TextButton(onClick = { openCommunity() }, enabled = !vm.communityLoading) {
                Text(if (vm.communityLoading) "Loading…" else "Refresh")
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = selected == null, onClick = { selected = null }, label = { Text("All") })
            Operators.forEach { op ->
                FilterChip(
                    selected = selected == op.name,
                    onClick = { selected = if (selected == op.name) null else op.name },
                    label = { Text(op.name) }
                )
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf<Pair<Int?, String>>(null to "Any distance", 10 to "10 m", 100 to "100 m", 1000 to "1 km").forEach { (v, label) ->
                FilterChip(selected = radius == v, onClick = { radius = v }, label = { Text(label) })
            }
            FilterChip(selected = false, onClick = {
                val g = holder.overlay?.myLocation
                if (g != null) {
                    holder.map?.controller?.setZoom(18.0)
                    holder.map?.controller?.animateTo(g)
                } else if (!hasLocationPermission(ctx)) askPermission()
            }, label = { Text("My location") })
        }
        if (showList) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        (if (tp != null) "Selected point" else "Near you") +
                            (if (fasterOnly) ": spots faster than your latest test" else ": measured spots") + " (${spots.size})",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                    if (fasterOnly && mine != null) Text("Your latest: ${f1(mine.download)} Mbps, ping ${f1(mine.pingMs)} ms", fontSize = 11.sp)
                    if (fasterOnly && mine == null) Text("Run a speed test first so I can compare.", fontSize = 11.sp)
                    if (refLa == null) Text("Waiting for GPS… or tap the map to choose a point.", fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(2000 to "2 km", 5000 to "5 km", 0 to "All").forEach { (v, label) ->
                            FilterChip(selected = tapRadius == v, onClick = { tapRadius = v }, label = { Text(label) })
                        }
                    }
                    if (spots.isEmpty()) Text(
                        "No measured spots here yet. Run tests or Auto-scan nearby" + (if (!community) ", or open Community." else "."),
                        fontSize = 12.sp
                    ) else Column(Modifier.heightIn(max = 190.dp).verticalScroll(rememberScrollState())) {
                        spots.forEachIndexed { i, (p, d) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${i + 1}. ${p.operator} ${f1(p.download)} Mbps, ping ${f1(p.ping)} ms" +
                                        (if (fasterOnly && mine != null) "  (+${f1(p.download - mine.download)} Mbps)" else "") +
                                        " • ${distText(d)}",
                                    fontSize = 12.sp, modifier = Modifier.weight(1f)
                                )
                                TextButton(onClick = { vm.target = p; vm.verifyMsg = ""; openMaps(ctx, p.lat, p.lon) }) { Text("Go") }
                            }
                        }
                    }
                    if (tp != null) TextButton(onClick = { tapPoint = null }) { Text("Close") }
                }
            }
        }
        if (tgt != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Target: ${tgt.operator} • recorded ${f1(tgt.download)} Mbps, ping ${f1(tgt.ping)} ms" +
                            (tgtDist?.let { d -> if (d < 1000) " • ${d.toInt()} m away" else " • %.1f km away".format(d / 1000) } ?: ""),
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                    if (vm.running) Text(vm.phase, fontSize = 12.sp)
                    if (vm.verifyMsg.isNotBlank()) Text(vm.verifyMsg, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (tgtDist != null && tgtDist <= 50f)
                            Button(onClick = { vm.start(tgt) }, enabled = !vm.running) { Text("I'm here, verify speed") }
                        else TextButton(onClick = { openMaps(ctx, tgt.lat, tgt.lon) }) { Text("Navigate") }
                        TextButton(onClick = { vm.target = null; vm.verifyMsg = "" }) { Text("Clear") }
                    }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    Configuration.getInstance().apply {
                        userAgentValue = c.packageName
                        osmdroidBasePath = File(c.cacheDir, "osmdroid")
                        osmdroidTileCache = File(c.cacheDir, "osmdroid/tiles")
                    }
                    MapView(c).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(5.0)
                        controller.setCenter(GeoPoint(22.5, 79.0))
                        val ov = MyLocationNewOverlay(GpsMyLocationProvider(c), this)
                        if (hasLocationPermission(c)) ov.enableMyLocation()
                        overlays.add(ov)
                        holder.overlay = ov
                        holder.map = this
                        overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
                            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                                tapPoint = p
                                if (community) vm.loadCommunityAt(p.latitude, p.longitude)
                                return true
                            }
                            override fun longPressHelper(p: GeoPoint): Boolean = false
                        }))
                    }
                },
                update = { map ->
                    val tick = permTick
                    holder.overlay?.let {
                        if (!it.isMyLocationEnabled && hasLocationPermission(map.context)) it.enableMyLocation()
                    }
                    map.overlays.filterIsInstance<Marker>().forEach { map.overlays.remove(it) }
                    points.forEach { r ->
                        val m = Marker(map)
                        m.setPosition(GeoPoint(r.lat, r.lon))
                        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        val ring = Operators.firstOrNull { it.name == r.operator }?.color?.toArgb()
                            ?: android.graphics.Color.WHITE
                        val fill = if (byPing) pingColor(r.ping) else qualityColor(r.download)
                        m.setIcon(GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(fill.toArgb())
                            setSize(52, 52)
                            setStroke(8, ring)
                        })
                        m.setTitle("${r.operator} • ${r.connection}")
                        m.setSnippet("Down ${f1(r.download)} | Up ${fu(r.upload)} Mbps | Ping ${f1(r.ping)} ms | ${fmtTime(r.time)}")
                        map.overlays.add(m)
                    }
                    tapPoint?.let { t ->
                        val m = Marker(map)
                        m.setPosition(t)
                        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        m.setIcon(GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(android.graphics.Color.WHITE)
                            setSize(36, 36)
                            setStroke(8, android.graphics.Color.BLACK)
                        })
                        m.setTitle("Selected point")
                        map.overlays.add(m)
                    }
                    val key = if (community) "c" else "m"
                    if (centered.key != key && points.isNotEmpty() && !holder.liveCentered) {
                        val la = if (community && vm.myLat != null) vm.myLat!! else points[0].lat
                        val lo = if (community && vm.myLon != null) vm.myLon!! else points[0].lon
                        map.controller.setZoom(if (community) 13.0 else 15.0)
                        map.controller.setCenter(GeoPoint(la, lo))
                        centered.key = key
                    }
                    map.invalidate()
                }
            )
            if (points.isEmpty()) {
                Surface(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                ) {
                    Text(
                        if (community) (if (vm.communityLoading) "Loading…" else vm.communityMsg.ifBlank { "No community tests for this filter." })
                        else "No located tests for this filter.\nRun a speed test with location allowed.",
                        Modifier.padding(16.dp), fontSize = 13.sp
                    )
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (byPing) { SourceChip("Good <50 ms", Good); SourceChip("Average 50-100", Average); SourceChip("Poor >100", Poor) }
            else { SourceChip("Good 20+ Mbps", Good); SourceChip("Average 5-20", Average); SourceChip("Poor <5", Poor) }
        }
        if (summary.isNotEmpty()) Text(
            (if (byPing) "Avg ping: " else "Avg download: ") + summary.joinToString("  |  "), fontSize = 12.sp
        )
        if (best != null) Text(
            (if (byPing) "Fastest ping spot: ${best.operator} ${f1(best.ping)} ms" else "Fastest spot: ${best.operator} ${f1(best.download)} Mbps") +
                (bestDist?.let { d -> if (d < 1000) ", about ${d.toInt()} m away" else ", about %.1f km away".format(d / 1000) } ?: ""),
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold
        )
        if (best != null && tgt == null) TextButton(onClick = {
            vm.target = best; vm.verifyMsg = ""; openMaps(ctx, best.lat, best.lon)
        }) { Text("Go to fastest spot") }
        if (tp == null) Text("Tap anywhere on the map to see the fastest measured spots near that point.", fontSize = 11.sp)
        if (vm.scanning) Text("Auto-scan: ${vm.scanMsg} • samples saved: ${vm.scanCount}", fontSize = 11.sp)
        Text(
            (if (live != null) "Live location on. " else "Waiting for GPS… ") +
                (if (community) "Community tests are user-submitted (unverified) and shared with location rounded to ~100 m, so the 10 m filter is exact only for My tests."
                else "Historical: your own saved tests. Ring color = operator."),
            fontSize = 11.sp
        )
    }
}

@Composable
fun SpeedTestScreen(vm: NetViewModel) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.start() }
    Page {
        Speedometer(vm.liveSpeed, meterMax(vm.liveSpeed))
        if (vm.running || vm.liveSpeed != null) SourceChip("Live measured (Cloudflare servers)", Good)
        Text(vm.phase, fontSize = 14.sp)
        vm.error?.let { Text(it, color = Poor, fontSize = 13.sp) }
        Button(onClick = {
            if (vm.saveLocation && !hasLocationPermission(ctx))
                permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            else vm.start()
        }, enabled = !vm.running) {
            Text(if (vm.running) "TESTING…" else "START TEST")
        }
        Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", f1(vm.download), Modifier.weight(1f))
            StatCard("Upload", f1(vm.upload), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping (ms)", f1(vm.ping), Modifier.weight(1f))
            StatCard("Jitter (ms)", f1(vm.jitter), Modifier.weight(1f))
        }
        Text("Ping is HTTP round-trip time. Results use mobile data if you are on mobile data.", fontSize = 11.sp)
    }
}

@Composable
fun CompareScreen(vm: NetViewModel) {
    val stats = Operators.map { op ->
        val l = vm.history.filter { it.operator == op.name }
        op to l
    }
    val bestDown = stats.filter { it.second.isNotEmpty() }.maxOfOrNull { it.second.map { r -> r.download }.average() } ?: 0.0
    val withData = stats.filter { it.second.isNotEmpty() }
    Page {
        SourceChip("Historical: your own saved tests on this device", Color(0xFF1E5BFF))
        stats.forEach { (op, l) ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(op.color))
                        Spacer(Modifier.width(8.dp))
                        Text(op.name, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${l.size} tests", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (l.isEmpty()) Text("No tests yet", fontSize = 13.sp)
                    else {
                        val d = l.map { it.download }.average()
                        Text("Down ${f1(d)} | Up ${f1(l.map { it.upload }.filter { it > 0.0 }.takeIf { it.isNotEmpty() }?.average())} Mbps | Ping ${f1(l.map { it.pingMs }.average())} ms", fontSize = 13.sp)
                        LinearProgressIndicator(progress = { (d / bestDown).toFloat().coerceIn(0f, 1f) },
                            Modifier.fillMaxWidth().padding(top = 8.dp), color = op.color)
                    }
                }
            }
        }
        val best = withData.maxByOrNull { it.second.map { r -> r.download }.average() }
        Text(
            if (withData.size >= 2 && best != null) "Best download so far: ${best.first.name}"
            else "Run tests on at least 2 operators (switch SIMs) to compare.",
            fontSize = 13.sp
        )
    }
}

@Composable
fun HistoryScreen(vm: NetViewModel) {
    if (vm.history.isEmpty()) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.History, null, Modifier.size(56.dp))
            Text("No speed tests saved yet", fontWeight = FontWeight.SemiBold)
            Text("Your results will appear here.", fontSize = 13.sp)
        }
    } else Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { vm.clearHistory() }, Modifier.align(Alignment.End)) { Text("Clear all") }
        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.history) { r ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${r.operator} • ${r.connection}", fontWeight = FontWeight.SemiBold)
                        Text(fmtTime(r.time) + if (r.lat != null) "  •  location saved" else "", fontSize = 12.sp)
                        Text("Down ${f1(r.download)} | Up ${fu(r.upload)} Mbps | Ping ${f1(r.pingMs)} ms" + if (r.upload <= 0.0) "  (auto-scan sample)" else "", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: NetViewModel, dark: Boolean, onDark: (Boolean) -> Unit) {
    Page {
        ListItem(
            headlineContent = { Text("Dark mode") },
            trailingContent = { Switch(checked = dark, onCheckedChange = onDark) }
        )
        ListItem(
            headlineContent = { Text("Save location with speed tests") },
            supportingContent = { Text("Used to place your tests on your map. Stored on this phone.") },
            trailingContent = { Switch(checked = vm.saveLocation, onCheckedChange = { vm.setSaveLoc(it) }) }
        )
        ListItem(
            headlineContent = { Text("Share anonymous measurements") },
            supportingContent = {
                Text(
                    if (Config.enabled)
                        "Off by default. When on, each mobile-data test uploads: operator, network type, speeds, time and location rounded to ~100 m. No name, phone number or device ID. Wi-Fi tests are never shared."
                    else "Community sharing is not set up in this build yet."
                )
            },
            trailingContent = { Switch(checked = vm.shareData && Config.enabled, onCheckedChange = { vm.setShare(it) }, enabled = Config.enabled) }
        )
        ListItem(headlineContent = { Text("NetTrack v0.8") }, supportingContent = { Text("Find Better Network. Experience Faster Internet.") })
    }
}
